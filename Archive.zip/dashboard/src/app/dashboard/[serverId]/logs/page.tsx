
import { LogViewer } from "@/components/logs/log-viewer"
import { ScrollText } from "lucide-react"

import { getSession } from "@/lib/auth-clerk"
import { redirect } from "next/navigation"
import { checkConnectionRequirements } from "@/lib/auth-server"
import { ConnectionRequirementScreen } from "@/components/auth/connection-requirement-screen"
import { RoleSyncWrapper } from "@/components/auth/role-sync-wrapper"

export default async function LogsPage({ params }: { params: Promise<{ serverId: string }> }) {
    const session = await getSession()
    if (!session) redirect("/login")

    // Enforce Connection Requirements
    const check = checkConnectionRequirements(session.user)
    if (!check.valid) {
        return (
            <ConnectionRequirementScreen
                missing={check.missing}
                discordUsername={session.user.username}
                robloxUsername={check.robloxUsername}
            />
        )
    }

    const { serverId } = await params

    return (
        <RoleSyncWrapper serverId={serverId}>
            <div className="space-y-6">
                <div className="flex items-center gap-3">
                    <div className="rounded-lg bg-indigo-500/10 p-2 text-indigo-400">
                        <ScrollText className="h-6 w-6" />
                    </div>
                    <h1 className="text-2xl font-bold text-white">Live Logs</h1>
                </div>

                <LogViewer serverId={serverId} />
            </div>
        </RoleSyncWrapper>
    )
}
